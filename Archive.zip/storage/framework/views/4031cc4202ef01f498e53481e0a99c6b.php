<form method="POST" action="<?php echo e(route('/api/login')); ?>">
    <?php echo csrf_field(); ?>
    <input type="email" name="email" required>
    <input type="password" name="password" required>
    <button type="submit">Login</button>
</form><?php /**PATH /home/kazuho/Documents/Freelas/TesteBuzzvel/REST/resources/views/mylogin.blade.php ENDPATH**/ ?>